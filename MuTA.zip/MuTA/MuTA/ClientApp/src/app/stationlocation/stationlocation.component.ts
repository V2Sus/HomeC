﻿import { Component, OnInit } from '@angular/core';
import { GetLocationService } from './shared/getlocation.service';
import { SaveLocationsService } from './shared/savelocations.service';
import { LocationModel } from './shared/location.model';

@Component({
    selector: 'app-stationlocation',
    templateUrl: './stationlocation.component.html',
    styleUrls: ['./stationlocation.component.scss']
})
/** stationlocation component*/
export class StationlocationComponent implements OnInit{
    /** stationlocation ctor */
    constructor(public service: GetLocationService, public savedata: SaveLocationsService) {       
    }
    
    ngOnInit(): void {
        this.startTimer();  
    }

    timeLeft: number = 1;
    interval;

    startTimer() {
        this.interval = setInterval(() => {
            if (this.timeLeft > 0) {
                this.timeLeft--;
            } else {
                this.timeLeft = 1;
                this.service.get();
            }
        }, 1000)
    }

    pauseTimer() {
        clearInterval(this.interval);
    }

    show: boolean = false;
    buttonName: any = 'Note';
    note: string = '';
    list: LocationModel[] = [];

    toggle() {
        
        this.show = !this.show;
        // CHANGE THE NAME OF THE BUTTON.
        if (this.show) {
            this.pauseTimer();
            this.buttonName = "Save";
        }
        else {
            this.buttonName = "Note";
            if (this.note.length > 0) {
                this.service.location.note = this.note;
                this.list.push(this.service.location);
                this.note = '';
            }
            this.startTimer();
        }
    }

    savelocations() {
        if (this.list.length > 0) {
            this.pauseTimer();
            this.savedata.post(this.list);
            this.startTimer();
        }

    }

}