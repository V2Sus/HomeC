"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetLocationService = void 0;
//import { Injectable } from '@angular/core';
//@Injectable({
//    providedIn: 'root'
//})
var GetLocationService = /** @class */ (function () {
    function GetLocationService(http) {
        this.http = http;
        this.baseURL = 'http://api.open-notify.org/iss-now.json';
    }
    GetLocationService.prototype.get = function () {
        var _this = this;
        this.http.get(this.baseURL)
            .toPromise()
            .then(function (res) { return _this.location = res; });
    };
    return GetLocationService;
}());
exports.GetLocationService = GetLocationService;
//# sourceMappingURL=getlocation.service.js.map