"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocationModel = void 0;
var LocationModel = /** @class */ (function () {
    function LocationModel() {
        this.message = '';
        this.timestamp = '';
        this.note = '';
    }
    return LocationModel;
}());
exports.LocationModel = LocationModel;
//# sourceMappingURL=location.model.js.map