﻿import { HttpClient } from "@angular/common/http";
import { LocationModel } from './location.model';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})

export class GetLocationService {

    constructor(private http: HttpClient) { }

    readonly baseURL = 'http://api.open-notify.org/iss-now.json'

    location: LocationModel;

    get() {
        this.http.get(this.baseURL)
            .toPromise()
            .then(res => this.location = res as LocationModel);
    }


}