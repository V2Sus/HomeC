﻿import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { LocationModel } from './location.model';
import { Injectable, Inject } from '@angular/core';
//import { Component, Inject } from '@angular/core';

@Injectable({
    providedIn: 'root'
})

export class SaveLocationsService {

    constructor(private http: HttpClient) {
       
    }
    baseUrl: string = 'http://localhost:42054/stationlocation';

    post(locations: LocationModel[]) {
        const headers = new HttpHeaders()
            .append(
                'Content-Type',
                'application/json'
        );
        const params = new HttpParams()
            .append('param1', 'some data 1')
            .append('param2', 'some data 2');
        const body = JSON.stringify(locations);
        //console.log(body)
        this.http
            .post<any>(this.baseUrl, body, {
                headers: headers,
                params: params,
            })
           .subscribe((res) => console.log(res));

    }


}