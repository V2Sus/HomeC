﻿export class LocationModel {
    message: string = '';
    iss_position:
        {
        latitude: string;
        longitude: string;
        }
    timestamp: string = '';
    note: string = '';
}