﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MuTA.Models
{
    public class IssPosition
    {
        public string longitude { get; set; }
        public string latitude { get; set; }
    }

    public class StationLocation
    {
        public IssPosition iss_position { get; set; }
        public string message { get; set; }
        public int timestamp { get; set; }
        public string note { get; set; }
    }

}
