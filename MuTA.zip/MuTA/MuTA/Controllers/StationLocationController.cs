﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MuTA.Models;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace MuTA.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class StationLocationController : ControllerBase
    {
        public StationLocationController()
        {
        }

        [HttpPost]
        public bool Post([FromBody] IEnumerable<StationLocation> locations)
        {            
           return saveToFile(locations);
        }

        private bool saveToFile(IEnumerable<StationLocation> locations)
        {
            bool ret = true;
            try
            {
                string json = JsonSerializer.Serialize(locations);
                System.IO.File.WriteAllText("stationlocations.json", json);
            }
            catch(Exception e)
            {
                ret = false;
            }
            return ret;
        }
    }
}
